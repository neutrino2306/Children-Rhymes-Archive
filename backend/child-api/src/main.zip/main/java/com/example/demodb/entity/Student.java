package com.example.demodb.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
//这个操作就是创建了一张 student表
@Data
@Entity  //加上这个 实体 注解 后， 说明要把他 整体 放在 数据库里面。标注了这个注解之后，每一个类的实例对象就会存到数据库表中。
public class Student {  //标红是因为  没有把这个 实体 持久化（也就是把他写进数据库）（那么也就需要主键
    @Id  //主键一般是叫做 id
    String id;
    String name;
    Integer age;  //最好是用 类 Integer来写。no  int！

}
