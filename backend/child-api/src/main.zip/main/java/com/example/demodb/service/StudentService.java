package com.example.demodb.service;

import com.example.demodb.entity.Student;
import com.example.demodb.repository.IStudentRepository;
import org.springframework.stereotype.Service;

@Service
public class StudentService {


    private final IStudentRepository studentRepository;

    public StudentService(IStudentRepository studentRepository){
        this.studentRepository = studentRepository;
    }

    public void init(){  //创建了一个新歌学生对象
        if(this.studentRepository.findById("20211120") != null){  //如果db中已经有目标id，那么就不需要创建这个学生对象
            System.out.println("=====================");
            System.out.println("记录已存在！");
            System.out.println("=====================");
            return;  //那么这个的findById方法是从哪来的？是从这个Repository类的爸爸（japRepository）继承而来的。
        }
        Student student = new Student();
        student.setId("20211120");
        student.setName("Anna");
        student.setAge(18);
        this.studentRepository.save(student);
    }
}
