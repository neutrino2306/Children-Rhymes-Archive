package com.example.demodb.repository;

import com.example.demodb.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IStudentRepository extends JpaRepository<Student, String> {  //这类 repository一般是针对某类实体 来进行操作的
    Student findByAge(Integer age); //返回一个Student对象，针对Age字段进行查询，但具体实现也不用管，jap会帮我们写的。


}
