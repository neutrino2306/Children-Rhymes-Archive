package com.example.demodb;

import com.example.demodb.entity.Student;
import com.example.demodb.service.StudentService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemodbApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemodbApplication.class, args);
    }
    @Bean  //先去找 这个bean，然后
    CommandLineRunner runner(StudentService studentService){  //commandlineRunner是返回类型
        return args -> {
            studentService.init();

            //每次启动这个服务，都会调用这个方法，显然是不合理的
        };
    }

}

